result = check_malware(url, api_key)
    print(result)